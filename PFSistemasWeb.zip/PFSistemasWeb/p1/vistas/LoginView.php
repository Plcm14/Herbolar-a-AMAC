<?php
// Incluye Encabezado
require_once '_Encabezado.php';
?>

<div class="container">
    <div class="row">
        <div class="col-md-12">
           
            <div class="wrap" id="titulo1">
                <ul class="nav navbar-nav navbar-right">
                 <li><a href="<?php echo $helper->url( "registro" ); ?>">Crear una cuenta</a></li>
               </ul><br><br><br><br>
          <p class="form-title">Iniciar sesión</p>
                               
                                <form action="<?php echo $helper->url( "login", "indexPOST" ); ?>" method="post" role="form">
                                <div class="form-group">
                                    <input class="form-control" name="username" placeholder="Correo electrónico" type="text" />
                                </div>
                                <div class="form-group">
                                    <input class="form-control" name="password" placeholder="Contraseña" type="password" />
                                </div>
                                <div class="form-group text-center">
                                    <button name="btnEntrar" class="btn btn-primary" type="submit">Entrar</button>
                                </div>
                        </form>
            </div>
        </div>
    </div>
    <div class="posted-by"><?php require_once '_Pie.php';
?></div>
</div>











<!-- Scripts -->
<script src="js/login.js"></script>
<link rel="stylesheet" href="css/estilos.css">
<link rel="stylesheet" href="css/style.css">

<?php
// Incluye el pie
require_once '_Pie.php';
?>

