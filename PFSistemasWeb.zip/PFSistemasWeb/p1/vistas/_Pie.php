
    <div class="text-center" id="titulo1">© 2017 Sistemas Web. Facultad de Estadística e Informática. Universidad Veracruzana.</div>
    </body>
</html>
