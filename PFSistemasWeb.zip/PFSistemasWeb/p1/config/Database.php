<?php
return array(
	"driver" => "mysql",
	"host" => "localhost",
	"user" => "root",
	"pass" => "",
	"database" => "proyectofinal",
	"charset" => "utf8mb4"
);
?>