<?php
define("TITULO", "Proyecto Final 2017");
define("SUBTITULO", "Sistemas Web");
define("CONTROLADOR_DEFECTO", "Home");
define("ACCION_DEFECTO", "index");
define("UPLOADS_DIR", "uploads");
define("FILE","nose");
?>
