package com.bda.androiddbex;

import android.app.Activity;
import android.os.Bundle;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
	SQLiteDatabase db;
	TextView txtMsg;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		txtMsg = (TextView) findViewById(R.id.txtMsg);
		
		try { 
			openDatabase(); //open (create if needed) database
			dropTable(); //if needed drop table tblAmigos
			insertSomeDbData(); //create-populate tblAmigos
			useRawQuery1(); //fixed SQL with no arguments
			/*useRawQuery2(); //parameter substitution
			useRawQuery3(); //manual string concatenation
			useSimpleQuery1(); //simple query
			useSimpleQuery2(); //nontrivial 'simple query'*/
			useCursor1(); //retrieve rows from a table
			updateDB(); //use execSQL to update
			/*useInsertMethod(); //use insert method
			useUpdateMethod(); //use update method
			useDeleteMethod(); //use delete method */
			
			db.close();//make sure to release the DB
			Toast.makeText(this,"All done!",1).show(); 
			
		} catch (Exception e) {
			Toast.makeText(this,e.getMessage(),1).show(); }
	}

	private void openDatabase() {
	       try {
	    	   db = SQLiteDatabase.openDatabase( "data/data/com.bda.androiddbex/myfriendsDB",
	    			   null,
	    			   SQLiteDatabase.CREATE_IF_NECESSARY) ; 
	    	   Toast.makeText(this, "DB was opened!", 1).show();
	}
	catch (SQLiteException e) {
		Toast.makeText(this, e.getMessage(), 1).show();
		}
	       
	}//createDatabase
		
}
