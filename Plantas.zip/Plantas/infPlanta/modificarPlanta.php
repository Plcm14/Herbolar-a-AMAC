<!DOCTYPE html>
<html lang="en">
<head>
	<title>Registro Plantas</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="../Galeria-Plantas/images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../Galeria-Plantas/vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../Galeria-Plantas/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../Galeria-Plantas/fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../Galeria-Plantas/vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="../Galeria-Plantas/vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../Galeria-Plantas/vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../Galeria-Plantas/vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="../Galeria-Plantas/vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="../Galeria-Plantas/css/util.css">
	<link rel="stylesheet" type="text/css" href="../Galeria-Plantas/css/main.css">
<!--===============================================================================================-->
</head>
<body>
	
		<div class="limiter">
		<div class="container-login100" style="background-image: url('images/bg-02.jpg');">
			<div class="wrap-login100p p-t-30 p-b-50">
				<span class="login100-form-title p-b-41">
					Registro de Plantas
				</span>


				<?php
					include("../Galeria-Plantas/conexion.php");
					$query = "SELECT * FROM planta WHERE id_Planta='$id'";
					$resultado = $conexion->query($query);
					$row=$resultado->fetch_assoc();
					
				?>


				<form class="login100-form validate-form p-b-33 p-t-5" action="guardarImg.php" target="_blank" method="POST" enctype="multipart/form-data">

					  
                    <div class="wrap-input100 validate-input" data-validate = "Enter name">
						<input class="input100" type="text" id="name" name="name" placeholder="Nombre" value="<?php echo $row['nombre']; ?>">
						<span class="focus-input100" data-placeholder="&#xe82a;"></span>
					</div>
                    
                    <div class="wrap-input100 validate-input" data-validate = "Enter categoria">
						<input class="input100" type="text" id="categoria" name="categoria" placeholder="Categoria" value="<?php echo $row['categoria']; ?>">
						<span class="focus-input100" data-placeholder="&#xe82a;"></span>
					</div>

                    <div class="wrap-input100 validate-input">
						
						 <img class="featurette-image img-fluid mx-auto" src="data:image/jpeg;base64,<?php echo base64_encode($row['foto']);?>" alt="Generic placeholder image">

						<input class="input100" name="imagen" type="file" >

						<span class="focus-input100" data-placeholder="&#xe82a;"></span>
                    </div>

					<div class="wrap-input100 validate-input" data-validate="Enter nombre cientifico">
						<input class="input100" type="text" id="nombreC" name="nombreC" placeholder="Nombre Cientifico" value="<?php echo $row['nombreC']; ?>">
						<span class="focus-input100" data-placeholder="&#xe82a;"></span>
					</div>

					<div class="wrap-input100 validate-input" data-validate="Enter caracteristica">
						<input class="input100" type="text" id="caracteristicas" name="caracteristicas" placeholder="Caracteristicas" value="<?php echo $row['caracteristicas']; ?>">
						<span class="focus-input100" data-placeholder="&#xe82a;"></span>
					</div>


					<div class="wrap-input100 validate-input" data-validate="Enter propiedades">
						<input class="input100" type="text" id="propiedades" name="propiedades" placeholder="Propiedades" value="<?php echo $row['propiedades']; ?>">
						<span class="focus-input100" data-placeholder="&#xe82a;"></span>
					</div>

                    
					<div class="wrap-input100 validate-input" data-validate="Enter usos">
						<input class="input100" type="text" id="usos" name="usos" placeholder="Usos" value="<?php echo $row['usos']; ?>">
						<span class="focus-input100" data-placeholder="&#xe82a;"></span>
					</div>

					
					<div class="container-login100-form-btn m-t-32">
						<button class="login100-form-btn" value="enviar">
							<a href="/Plantas/pAdministrador.html">Enviar</a>
						</button>
					</div>

				</form>
			</div>
		</div>
	</div>
	

	<div id="dropDownSelect1"></div>
	
<!--===============================================================================================-->
	<script src="../Galeria-Plantas/vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="../Galeria-Plantas/vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="../Galeria-Plantas/vendor/bootstrap/js/popper.js"></script>
	<script src="../Galeria-Plantas/vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="../Galeria-Plantas/vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="../Galeria-Plantas/vendor/daterangepicker/moment.min.js"></script>
	<script src="../Galeria-Plantas/vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="../Galeria-Plantas/vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="../Galeria-Plantas/js/main.js"></script>

</body>
</html>