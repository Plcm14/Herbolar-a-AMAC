
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../favicon.ico">

    <title>Galeria de nuestra HERBOLARIA</title>

    <!-- Bootstrap core CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="../css/carousel.css" rel="stylesheet">
  </head>
  <body>

    <nav class="navbar navbar-toggleable-md navbar-inverse fixed-top bg-inverse">
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <a class="navbar-brand" href="#">Herbolaria AMAC</a>
      
      <div class="collapse navbar-collapse" id="navbarCollapse">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
            <a class="nav-link" href="../Galeria-Plantas/registroPlanta.php">Subir Planta <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../Galeria-Plantas/tabla.php">Solicitudes</a>
          </li>
        </ul>
        <form class="form-inline mt-2 mt-md-0">
          <input class="form-control mr-sm-2" type="text" placeholder="Search">
          <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
        </form>
      </div>
      
    </nav>

      <!-- START THE FEATURETTES -->


          <hr class="featurette-divider">
          <?php

                        include("../Galeria-Plantas/conexion.php");
                        $query = "SELECT * FROM planta WHERE categoria = 'aromaticas'";
                        $resultado = $conexion->query($query);
                        while($row=$resultado->fetch_assoc()){
                      ?>

            <div class="col-md-7">

             <div class="container">
              <table>
                  <tbody>

                      <tr> <h2 class="featurette-heading"> <?php echo $row['nombre']; ?> </h></tr>
                      <tr><p class="lead">Categoría: <?php echo $row['categoria']; ?></tr><br>
                      <tr><p class="lead">Nombre cientifico: <?php echo $row['nombreC']; ?></tr><br> 
                      <tr><p class="lead">Características: <?php echo $row['caracteristicas']; ?></tr><br>
                      <tr><p class="lead">Propiedades: <?php echo $row['propiedades']; ?></tr><br> 
                      <tr><p class="lead">Usos: <?php echo $row['usos']; ?></tr><br>

                  </tbody>  
              </table>
             </div>    
            </div>

            <div class="col-md-5">
             <img class="featurette-image img-fluid mx-auto" src="data:image/jpeg;base64,<?php echo base64_encode($row['foto']);?>" alt="Generic placeholder image">
            </div> 
            <hr>
               <?php
                }
              ?>
      <hr class="featurette-divider">

      <!-- /END THE FEATURETTES -->


      <!-- FOOTER -->
     <footer>
        <p class="float-right"><a href="#">Ir arriba</a></p>
        <p>&copy; 2019 Tecnologias Computacionales: Equipo A en Desarrollo de Software</a></p>
      </footer>

    </div><!-- /.container -->


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-3.1.1.slim.min.js" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery.min.js"><\/script>')</script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
    <script src="../dist/js/bootstrap.min.js"></script>
    <!-- Just to make our placeholder images work. Don't actually copy the next line! -->
    <script src="../assets/js/vendor/holder.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="../assets/js/ie10-viewport-bug-workaround.js"></script>
  </body>
</html>
