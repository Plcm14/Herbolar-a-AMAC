<?php

	include("conexion.php");
	$name =  $_POST['name'];
	$categoria =  $_POST['categoria'];
	$imagen = addslashes(file_get_contents($_FILES['imagen']['tmp_name']));
	$nombreC =  $_POST['nombreC'];
	$caracteristicas =  $_POST['caracteristicas'];
	$propiedades =  $_POST['propiedades'];
	$usos =  $_POST['usos'];

 	$query = "INSERT INTO planta (nombre, categoria , foto, nombreC , caracteristicas, propiedades, usos) Values('$name', '$categoria', '$imagen', '$nombreC' , '$caracteristicas' , '$propiedades', '$usos')";
    $resultado = $conexion->query($query);

    if($resultado){
        header("Location: /Plantas/pAdministrador.html");
    }
    else{
        echo "Error al insertar los datos";
    }

?>