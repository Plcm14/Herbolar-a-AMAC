<!Doctype html>
<html lang="es">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width-device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <title>Sesion</title>

  </head>
  <body>
  <header class="header">
      <div class="contenedor">
        <h1 class="logo">Bienvenido </h1>
        <span class="icon-menu" id="btn-menu"></span>
      </div>
    </header>
      <?php
        session_start();
        session_destroy();
      
        include("conexion.php");

        if(isset($_SESSION['u_usuario'])){

          $user = $_SESSION['u_usuario'];
    
          echo 'Usuario: '.$_SESSION['u_usuario']. "<br>";
          echo "<a href='cerrarS.php'>Cerrar Sesión</a>" . "<br>";   
          
    }else{
      header("Location: index.php");
    }
      ?> 
    </div>    
  </body>
</html>