<?php

$conexion = new mysqli("localhost", "root", "oppa123", "GaleriaPlantas");

?>
