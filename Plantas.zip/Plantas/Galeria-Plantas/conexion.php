<?php

$conexion = new mysqli("localhost", "root", "clasebd", "GaleriaPlantas");

?>
