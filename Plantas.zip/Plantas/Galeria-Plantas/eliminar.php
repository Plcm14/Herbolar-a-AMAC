<?php

include("conexion.php");

    $id=$_REQUEST['id'];
 
    $query = "DELETE FROM usuario WHERE id_Usuario = '$id' ";
    $resultado = $conexion->query($query);

    if($resultado){
        header("Location: tabla.php");
    }
    else{
        echo "Error al borrar los datos";
    }

?>
