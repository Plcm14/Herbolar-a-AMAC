<?php
 session_start();

 $user =  $_POST['user'];
 $pass =  $_POST['pass'];


 include("conexion.php");

 $proceso = $conexion->query("SELECT * FROM usuario WHERE correo = '$user' AND passwordU = '$pass' ");

    if($resultado = mysqli_fetch_array($proceso)){
        $_SESSION['u_usuario'] = $user;
        
        header("Location: /../pAdministrador.html");
    }else{
        header("Location: index.php");
        
    }
?>