<?php

include("conexion.php");

    $user =  $_POST['user'];
    $pass =  $_POST['pass'];
    $name =  $_POST['name'];
    $tipo =  $_POST['tipo'];

    $query = "INSERT INTO usuario (correo, passwordU , nombre, tipo) Values('$user', '$pass', '$name', '$tipo')";
    $resultado = $conexion->query($query);

    if($resultado){
        echo "Interseccion Exitosa";
    }
    else{
        echo "Error al insertar los datos";
    }

?>