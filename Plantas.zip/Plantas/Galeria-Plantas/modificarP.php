<?php

include("conexion.php");

    $id=$_REQUEST['id'];
    $user =  $_POST['user'];
    $pass =  $_POST['pass'];
    $name =  $_POST['name'];
    $tipo =  $_POST['tipo'];

    $query = "UPDATE usuario SET correo = '$user', passwordU= '$pass', nombre = '$name', tipo = '$tipo' WHERE id_Usuario = '$id' ";
    $resultado = $conexion->query($query);

    if($resultado){
        header("Location: tabla.php");
    }
    else{
        echo "Error al insertar los datos";
    }

?>